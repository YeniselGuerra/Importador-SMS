package com.inventario.importadorsms

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

/**
 * Todos los datos de un telefono, con los mismos campos que la base de datos
 * de telefonos de "Factura Aniel" (pestaña Base de Datos de Telefonos).
 * Los campos versionAndroid, textoSms y fechaSms son solo para uso interno
 * de esta app y no se exportan (Factura Aniel no los tiene).
 */
data class Telefono(
    var numero: String,
    var dept: String = "",
    var trabajador: String = "",
    var ci: String = "",
    var cargo: String = "",
    var marca: String = "",
    var modelo: String = "",
    var imei: String = "",
    var tipo: String = "",
    var internet: String = "",
    var minutos: String = "",
    var megas: String = "",
    var smsPlan: String = "",
    var mac: String = "",
    var wifiIp: String = "",
    var simIp: String = "",
    var simPin: String = "",
    var simPuk: String = "",
    var desc: String = "",
    var versionAndroid: String = "",
    var textoSms: String = "",
    var fechaSms: Long = 0,
    var editado: Boolean = false
)

/**
 * Base de datos SQLite local de la app:
 *  - tabla "telefonos": un registro por numero de telefono (la misma clave
 *    que usa Factura Aniel).
 *  - tabla "departamentos": lista maestra de departamentos que viaja en el XML.
 */
class TelefonosDb(context: Context) : SQLiteOpenHelper(context, NOMBRE_BD, null, VERSION_BD) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE telefonos (" +
                "numero TEXT PRIMARY KEY, " +
                "dept TEXT DEFAULT '', " +
                "trabajador TEXT DEFAULT '', " +
                "ci TEXT DEFAULT '', " +
                "cargo TEXT DEFAULT '', " +
                "marca TEXT DEFAULT '', " +
                "modelo TEXT DEFAULT '', " +
                "imei TEXT DEFAULT '', " +
                "tipo TEXT DEFAULT '', " +
                "internet TEXT DEFAULT '', " +
                "minutos TEXT DEFAULT '', " +
                "megas TEXT DEFAULT '', " +
                "sms_plan TEXT DEFAULT '', " +
                "mac TEXT DEFAULT '', " +
                "wifi_ip TEXT DEFAULT '', " +
                "sim_ip TEXT DEFAULT '', " +
                "sim_pin TEXT DEFAULT '', " +
                "sim_puk TEXT DEFAULT '', " +
                "descripcion TEXT DEFAULT '', " +
                "version_android TEXT DEFAULT '', " +
                "texto_sms TEXT DEFAULT '', " +
                "fecha_sms INTEGER DEFAULT 0, " +
                "editado INTEGER DEFAULT 0)"
        )
        db.execSQL(
            "CREATE TABLE departamentos (nombre TEXT PRIMARY KEY, orden INTEGER NOT NULL)"
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, versionVieja: Int, versionNueva: Int) {
        // Si en el futuro cambia la estructura, aqui se migran los datos.
        db.execSQL("DROP TABLE IF EXISTS telefonos")
        db.execSQL("DROP TABLE IF EXISTS departamentos")
        onCreate(db)
    }

    /** Columnas en el orden que devuelve deCursor(). */
    private val COLUMNAS = arrayOf(
        "numero", "dept", "trabajador", "ci", "cargo", "marca", "modelo", "imei",
        "tipo", "internet", "minutos", "megas", "sms_plan", "mac", "wifi_ip",
        "sim_ip", "sim_pin", "sim_puk", "descripcion", "version_android",
        "texto_sms", "fecha_sms", "editado"
    )

    private fun deCursor(cur: android.database.Cursor): Telefono {
        val t = Telefono(numero = cur.getString(0) ?: "")
        t.dept = cur.getString(1) ?: ""
        t.trabajador = cur.getString(2) ?: ""
        t.ci = cur.getString(3) ?: ""
        t.cargo = cur.getString(4) ?: ""
        t.marca = cur.getString(5) ?: ""
        t.modelo = cur.getString(6) ?: ""
        t.imei = cur.getString(7) ?: ""
        t.tipo = cur.getString(8) ?: ""
        t.internet = cur.getString(9) ?: ""
        t.minutos = cur.getString(10) ?: ""
        t.megas = cur.getString(11) ?: ""
        t.smsPlan = cur.getString(12) ?: ""
        t.mac = cur.getString(13) ?: ""
        t.wifiIp = cur.getString(14) ?: ""
        t.simIp = cur.getString(15) ?: ""
        t.simPin = cur.getString(16) ?: ""
        t.simPuk = cur.getString(17) ?: ""
        t.desc = cur.getString(18) ?: ""
        t.versionAndroid = cur.getString(19) ?: ""
        t.textoSms = cur.getString(20) ?: ""
        t.fechaSms = cur.getLong(21)
        t.editado = cur.getInt(22) == 1
        return t
    }

    private fun aValores(t: Telefono): ContentValues {
        val v = ContentValues()
        v.put("numero", t.numero)
        v.put("dept", t.dept)
        v.put("trabajador", t.trabajador)
        v.put("ci", t.ci)
        v.put("cargo", t.cargo)
        v.put("marca", t.marca)
        v.put("modelo", t.modelo)
        v.put("imei", t.imei)
        v.put("tipo", t.tipo)
        v.put("internet", t.internet)
        v.put("minutos", t.minutos)
        v.put("megas", t.megas)
        v.put("sms_plan", t.smsPlan)
        v.put("mac", t.mac)
        v.put("wifi_ip", t.wifiIp)
        v.put("sim_ip", t.simIp)
        v.put("sim_pin", t.simPin)
        v.put("sim_puk", t.simPuk)
        v.put("descripcion", t.desc)
        v.put("version_android", t.versionAndroid)
        v.put("texto_sms", t.textoSms)
        v.put("fecha_sms", t.fechaSms)
        v.put("editado", if (t.editado) 1 else 0)
        return v
    }

    /** Devuelve el telefono guardado con ese numero, o null si no existe. */
    fun obtener(numero: String): Telefono? {
        val db = readableDatabase
        val cur = db.query("telefonos", COLUMNAS, "numero = ?", arrayOf(numero), null, null, null)
        val t = if (cur.moveToFirst()) deCursor(cur) else null
        cur.close()
        return t
    }

    /** Todos los telefonos ordenados por numero. */
    fun listar(): List<Telefono> {
        val lista = ArrayList<Telefono>()
        val db = readableDatabase
        val cur = db.query("telefonos", COLUMNAS, null, null, null, null, "numero ASC")
        while (cur.moveToNext()) lista.add(deCursor(cur))
        cur.close()
        return lista
    }

    /** Inserta o reemplaza un telefono (la clave es el numero). */
    fun guardar(t: Telefono) {
        val db = writableDatabase
        db.insertWithOnConflict("telefonos", null, aValores(t), SQLiteDatabase.CONFLICT_REPLACE)
    }

    /**
     * Guarda los datos que llegan por SMS: si el telefono es nuevo lo crea;
     * si ya existe, SO completa los campos que estan vacios (nunca pisa los
     * datos corregidos a mano por el usuario). Devuelve NUEVO o ACTUALIZADO.
     */
    fun guardarDesdeSms(t: Telefono): Int {
        val existente = obtener(t.numero)
        if (existente == null) {
            guardar(t)
            return NUEVO
        }
        fun mezclar(viejo: String, nuevo: String): String = if (viejo.isBlank()) nuevo else viejo
        existente.dept = mezclar(existente.dept, t.dept)
        existente.trabajador = mezclar(existente.trabajador, t.trabajador)
        existente.ci = mezclar(existente.ci, t.ci)
        existente.cargo = mezclar(existente.cargo, t.cargo)
        existente.marca = mezclar(existente.marca, t.marca)
        existente.modelo = mezclar(existente.modelo, t.modelo)
        existente.imei = mezclar(existente.imei, t.imei)
        existente.tipo = mezclar(existente.tipo, t.tipo)
        existente.internet = mezclar(existente.internet, t.internet)
        existente.minutos = mezclar(existente.minutos, t.minutos)
        existente.megas = mezclar(existente.megas, t.megas)
        existente.smsPlan = mezclar(existente.smsPlan, t.smsPlan)
        existente.mac = mezclar(existente.mac, t.mac)
        existente.wifiIp = mezclar(existente.wifiIp, t.wifiIp)
        existente.simIp = mezclar(existente.simIp, t.simIp)
        existente.simPin = mezclar(existente.simPin, t.simPin)
        existente.simPuk = mezclar(existente.simPuk, t.simPuk)
        existente.versionAndroid = mezclar(existente.versionAndroid, t.versionAndroid)
        existente.textoSms = t.textoSms
        existente.fechaSms = t.fechaSms
        guardar(existente)
        return ACTUALIZADO
    }

    fun eliminar(numero: String) {
        writableDatabase.delete("telefonos", "numero = ?", arrayOf(numero))
    }

    fun contar(): Int = contarSql("SELECT COUNT(*) FROM telefonos")

    fun contarSinDepartamento(): Int =
        contarSql("SELECT COUNT(*) FROM telefonos WHERE dept = ''")

    private fun contarSql(sql: String): Int {
        val db = readableDatabase
        val cur = db.rawQuery(sql, null)
        val n = if (cur.moveToFirst()) cur.getInt(0) else 0
        cur.close()
        return n
    }

    // ---------- Departamentos ----------

    /** Lista maestra de departamentos en su orden. */
    fun listarDepartamentos(): List<String> {
        val lista = ArrayList<String>()
        val db = readableDatabase
        val cur = db.query("departamentos", arrayOf("nombre"), null, null, null, null, "orden ASC")
        while (cur.moveToNext()) lista.add(cur.getString(0) ?: "")
        cur.close()
        return lista
    }

    fun contarDepartamentos(): Int {
        val db = readableDatabase
        val cur = db.rawQuery("SELECT COUNT(*) FROM departamentos", null)
        val n = if (cur.moveToFirst()) cur.getInt(0) else 0
        cur.close()
        return n
    }

    fun agregarDepartamento(nombre: String) {
        if (nombre.isBlank()) return
        val db = writableDatabase
        val cur = db.rawQuery("SELECT MAX(orden) FROM departamentos", null)
        val maximo = if (cur.moveToFirst()) cur.getInt(0) else 0
        cur.close()
        val v = ContentValues()
        v.put("nombre", nombre)
        v.put("orden", maximo + 1)
        db.insertWithOnConflict("departamentos", null, v, SQLiteDatabase.CONFLICT_IGNORE)
    }

    fun eliminarDepartamento(nombre: String) {
        writableDatabase.delete("departamentos", "nombre = ?", arrayOf(nombre))
    }

    /** Agrega a la lista maestra los departamentos usados por telefonos y que falten. */
    fun sincronizarDepartamentos() {
        val db = readableDatabase
        val cur = db.rawQuery("SELECT DISTINCT dept FROM telefonos WHERE dept != ''", null)
        val usados = ArrayList<String>()
        while (cur.moveToNext()) usados.add(cur.getString(0) ?: "")
        cur.close()
        for (d in usados) agregarDepartamento(d)
    }

    companion object {
        const val NUEVO = 0
        const val ACTUALIZADO = 1
        private const val NOMBRE_BD = "telefonos.db"
        private const val VERSION_BD = 1
    }
}
