package com.inventario.importadorsms

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Adapter de la lista: convierte cada SmsItem en una fila visual.
 */
class SmsListAdapter(private val context: Context) : BaseAdapter() {

    private var datos: List<SmsItem> = ArrayList()
    private val formato = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.US)

    /** Sustituye el contenido de la lista y la redibuja. */
    fun reemplazar(nuevos: List<SmsItem>) {
        datos = nuevos
        notifyDataSetChanged()
    }

    override fun getCount(): Int = datos.size

    override fun getItem(position: Int): Any? = datos[position]

    override fun getItemId(position: Int): Long = datos[position].idLocal

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val vista = convertView ?: LayoutInflater.from(context).inflate(R.layout.item_sms, parent, false)
        val mensaje = datos[position]

        val titulo = vista.findViewById(R.id.item_titulo) as TextView
        val fecha = vista.findViewById(R.id.item_fecha) as TextView
        val cuerpo = vista.findViewById(R.id.item_cuerpo) as TextView

        titulo.text = if (mensaje.tipo == SmsImporter.TIPO_RECIBIDO) {
            "De: " + mensaje.direccion
        } else {
            "Para: " + mensaje.direccion
        }
        fecha.text = formato.format(Date(mensaje.fechaUnix)) + "  •  " + mensaje.tipo
        cuerpo.text = mensaje.cuerpo

        return vista
    }
}
