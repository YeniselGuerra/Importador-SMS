package com.inventario.importadorsms

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Adapter de la lista principal: una fila por telefono registrado.
 */
class TelefonosListAdapter(private val context: Context) : BaseAdapter() {

    private var datos: List<Telefono> = ArrayList()
    private val formato = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.US)

    /** Sustituye el contenido de la lista y la redibuja. */
    fun reemplazar(nuevos: List<Telefono>) {
        datos = nuevos
        notifyDataSetChanged()
    }

    override fun getCount(): Int = datos.size

    override fun getItem(position: Int): Any? = datos[position]

    override fun getItemId(position: Int): Long = position.toLong()

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val vista = convertView ?: LayoutInflater.from(context).inflate(R.layout.item_telefono, parent, false)
        val t = datos[position]

        val titulo = vista.findViewById(R.id.item_numero) as TextView
        val detalle = vista.findViewById(R.id.item_detalle) as TextView
        val extra = vista.findViewById(R.id.item_extra) as TextView

        titulo.text = if (t.trabajador.isBlank()) t.numero else t.numero + "  ·  " + t.trabajador

        val equipo = listOf(t.marca, t.modelo).filter { it.isNotBlank() }.joinToString(" ")
        val conImei = if (t.imei.isBlank()) equipo else if (equipo.isBlank()) "IMEI " + t.imei else equipo + " · IMEI " + t.imei
        detalle.text = conImei.ifBlank { "Sin datos de equipo" }

        val depto = if (t.dept.isBlank()) "Sin asignar" else "Dept: " + t.dept
        val origen = if (t.fechaSms > 0) " · SMS " + formato.format(Date(t.fechaSms)) else " · Manual"
        val tocado = if (t.editado) " · editado" else ""
        extra.text = depto + origen + tocado

        return vista
    }
}
