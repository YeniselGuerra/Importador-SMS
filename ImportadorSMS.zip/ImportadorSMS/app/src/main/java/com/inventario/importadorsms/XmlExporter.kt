package com.inventario.importadorsms

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Genera el XML en el MISMO formato que usa "Factura Aniel" para
 * "Importar BD (XML)" (funcion importDatabase del archivo HTML):
 *
 *   <?xml version="1.0" encoding="UTF-8"?>
 *   <etecsa_db>
 *     <departments><dept>...</dept></departments>
 *     <phones>
 *       <phone number="..." dept="..." trabajador="..." ... >descripcion</phone>
 *     </phones>
 *   </etecsa_db>
 *
 * Notas importantes del lado de Factura Aniel:
 *  - Un <phone> sin atributo dept SE DESCARTA al importar, por eso los
 *    telefonos sin departamento se exportan con dept="Sin Asignar".
 *  - La lista de <departments> reemplaza la existente en Factura Aniel,
 *    por eso se exporta siempre la lista completa de la app.
 *  - La descripcion (desc) va como CONTENIDO del elemento <phone>, no como atributo.
 */
object XmlExporter {

    /** Resultado de una exportacion: uri de MediaStore (Android 10+) o archivo. */
    data class Exportado(val uri: Uri?, val archivo: File?)

    private val formatoNombre = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US)

    /** Escapa un texto para atributos XML y quita saltos de linea y control. */
    private fun esc(texto: String): String {
        val sb = StringBuilder(texto.length)
        for (c in texto) {
            when {
                c == '&' -> sb.append("&amp;")
                c == '<' -> sb.append("&lt;")
                c == '>' -> sb.append("&gt;")
                c == '\"' -> sb.append("&quot;")
                c == '\'' -> sb.append("&apos;")
                c == '\n' || c == '\r' || c == '\t' -> sb.append(' ')
                c < ' ' -> sb.append(' ')
                else -> sb.append(c)
            }
        }
        return sb.toString()
    }

    /** Construye el documento XML completo con todos los telefonos guardados. */
    fun construirXml(context: Context): String {
        val db = TelefonosDb(context)
        db.sincronizarDepartamentos()
        val departamentos = db.listarDepartamentos()
        val telefonos = db.listar()

        val sb = StringBuilder()
        sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n")
        sb.append("<etecsa_db>\n")

        sb.append("  <departments>\n")
        for (d in departamentos) {
            sb.append("    <dept>").append(esc(d)).append("</dept>\n")
        }
        sb.append("  </departments>\n")

        sb.append("  <phones>\n")
        for (t in telefonos) {
            val dept = if (t.dept.isBlank()) "Sin Asignar" else t.dept
            sb.append("    <phone number=\"").append(esc(t.numero)).append("\"")
                .append(" dept=\"").append(esc(dept)).append("\"")
                .append(" trabajador=\"").append(esc(t.trabajador)).append("\"")
                .append(" ci=\"").append(esc(t.ci)).append("\"")
                .append(" cargo=\"").append(esc(t.cargo)).append("\"")
                .append(" marca=\"").append(esc(t.marca)).append("\"")
                .append(" modelo=\"").append(esc(t.modelo)).append("\"")
                .append(" imei=\"").append(esc(t.imei)).append("\"")
                .append(" internet=\"").append(esc(t.internet)).append("\"")
                .append(" minutos=\"").append(esc(t.minutos)).append("\"")
                .append(" megas=\"").append(esc(t.megas)).append("\"")
                .append(" sms=\"").append(esc(t.smsPlan)).append("\"")
                .append(" mac=\"").append(esc(t.mac)).append("\"")
                .append(" wifi_ip=\"").append(esc(t.wifiIp)).append("\"")
                .append(" tipo=\"").append(esc(t.tipo)).append("\"")
                .append(" sim_ip=\"").append(esc(t.simIp)).append("\"")
                .append(" sim_pin=\"").append(esc(t.simPin)).append("\"")
                .append(" sim_puk=\"").append(esc(t.simPuk)).append("\">")
                .append(esc(t.desc)).append("</phone>\n")
        }
        sb.append("  </phones>\n")
        sb.append("</etecsa_db>\n")

        db.close()
        return sb.toString()
    }

    /**
     * Exporta la base local a un archivo XML en la carpeta Descargas.
     * En Android 10 o superior usa MediaStore y no necesita permisos.
     * En Android 9 o anterior hay que haber concedido WRITE_EXTERNAL_STORAGE.
     */
    fun exportar(context: Context): Exportado {
        val xml = construirXml(context)
        val nombre = "base_telefonos_etecsa_" + formatoNombre.format(Date()) + ".xml"

        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val valores = ContentValues()
            valores.put("_display_name", nombre)
            valores.put("mime_type", "application/xml")
            valores.put("relative_path", Environment.DIRECTORY_DOWNLOADS)
            val uri = context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, valores)
                ?: throw Exception("No se pudo crear el archivo en Descargas")
            val salida = context.contentResolver.openOutputStream(uri)
                ?: throw Exception("No se pudo abrir el archivo para escribir")
            salida.use { it.write(xml.toByteArray(Charsets.UTF_8)) }
            Exportado(uri = uri, archivo = null)
        } else {
            @Suppress("DEPRECATION")
            val carpeta = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            if (!carpeta.exists()) carpeta.mkdirs()
            val archivo = File(carpeta, nombre)
            FileOutputStream(archivo).use { it.write(xml.toByteArray(Charsets.UTF_8)) }
            Exportado(uri = null, archivo = archivo)
        }
    }
}
