package com.inventario.importadorsms

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Genera el XML con todos los mensajes de la base local y lo guarda en la
 * carpeta Descargas del telefono. Ese XML es el que se importa en la base
 * de datos del sistema de inventario.
 */
object XmlExporter {

    /** Resultado de una exportacion. En Android 10+ se devuelve la uri de
     *  MediaStore; en versiones anteriores, el archivo creado. */
    data class Exportado(val uri: Uri?, val archivo: File?)

    private val formatoFecha = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
    private val formatoCabecera = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US)
    private val formatoNombre = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US)

    /** Escapa un texto para que sea XML valido (quita caracteres de control). */
    private fun esc(texto: String): String {
        val sb = StringBuilder(texto.length)
        for (c in texto) {
            when {
                c == '&' -> sb.append("&amp;")
                c == '<' -> sb.append("&lt;")
                c == '>' -> sb.append("&gt;")
                c == '\"' -> sb.append("&quot;")
                c == '\'' -> sb.append("&apos;")
                c == '\n' || c == '\r' || c == '\t' -> sb.append(c)
                c < ' ' -> sb.append(' ')
                else -> sb.append(c)
            }
        }
        return sb.toString()
    }

    /** Construye el documento XML completo con todos los mensajes guardados. */
    fun construirXml(context: Context): String {
        val db = SmsDb(context)
        val mensajes = db.listarParaExportar()
        val sb = StringBuilder()

        sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n")
        sb.append("<mensajes_sms app=\"ImportadorSMS\" version=\"1.0\" total=\"")
            .append(mensajes.size)
            .append("\" exportado=\"")
            .append(formatoCabecera.format(Date()))
            .append("\">\n")

        for (m in mensajes) {
            sb.append("  <mensaje>\n")
            sb.append("    <id>").append(m.idLocal).append("</id>\n")
            sb.append("    <id_sistema>").append(esc(m.idSistema)).append("</id_sistema>\n")
            sb.append("    <tipo>").append(esc(m.tipo)).append("</tipo>\n")
            sb.append("    <telefono>").append(esc(m.direccion)).append("</telefono>\n")
            sb.append("    <fecha_unix>").append(m.fechaUnix).append("</fecha_unix>\n")
            sb.append("    <fecha>").append(formatoFecha.format(Date(m.fechaUnix))).append("</fecha>\n")
            sb.append("    <leido>").append(if (m.leido) "SI" else "NO").append("</leido>\n")
            sb.append("    <texto>").append(esc(m.cuerpo)).append("</texto>\n")
            sb.append("  </mensaje>\n")
        }

        sb.append("</mensajes_sms>\n")
        db.close()
        return sb.toString()
    }

    /**
     * Exporta la base local a un archivo XML en la carpeta Descargas.
     * En Android 10 o superior usa MediaStore y no necesita permisos.
     * En Android 9 o anterior hay que haber concedido WRITE_EXTERNAL_STORAGE.
     */
    fun exportar(context: Context): Exportado {
        val xml = construirXml(context)
        val nombre = "sms_export_" + formatoNombre.format(Date()) + ".xml"

        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val valores = ContentValues()
            valores.put("_display_name", nombre)
            valores.put("mime_type", "application/xml")
            valores.put("relative_path", Environment.DIRECTORY_DOWNLOADS)
            val uri = context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, valores)
                ?: throw Exception("No se pudo crear el archivo en Descargas")
            val salida = context.contentResolver.openOutputStream(uri)
                ?: throw Exception("No se pudo abrir el archivo para escribir")
            salida.use { it.write(xml.toByteArray(Charsets.UTF_8)) }
            Exportado(uri = uri, archivo = null)
        } else {
            @Suppress("DEPRECATION")
            val carpeta = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            if (!carpeta.exists()) carpeta.mkdirs()
            val archivo = File(carpeta, nombre)
            FileOutputStream(archivo).use { it.write(xml.toByteArray(Charsets.UTF_8)) }
            Exportado(uri = null, archivo = archivo)
        }
    }
}
