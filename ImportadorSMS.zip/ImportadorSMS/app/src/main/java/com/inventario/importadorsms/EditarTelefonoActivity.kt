package com.inventario.importadorsms

import android.app.AlertDialog
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

/**
 * Formulario con todos los campos de un telefono, los mismos que maneja la
 * pestaña "Base de Datos de Telefonos" de Factura Aniel. Se abre desde la
 * lista (edita un telefono existente) o desde "Agregar telefono" (crea uno).
 */
class EditarTelefonoActivity : AppCompatActivity() {

    private lateinit var db: TelefonosDb
    private lateinit var depts: List<String>
    private var numeroOriginal = ""

    private lateinit var etTrabajador: EditText
    private lateinit var etCi: EditText
    private lateinit var etCargo: EditText
    private lateinit var etNumero: EditText
    private lateinit var etMarca: EditText
    private lateinit var etModelo: EditText
    private lateinit var etImei: EditText
    private lateinit var spTipo: Spinner
    private lateinit var spInternet: Spinner
    private lateinit var etMinutos: EditText
    private lateinit var etMegas: EditText
    private lateinit var etSmsPlan: EditText
    private lateinit var etMac: EditText
    private lateinit var etWifiIp: EditText
    private lateinit var etSimIp: EditText
    private lateinit var etSimPin: EditText
    private lateinit var etSimPuk: EditText
    private lateinit var etDesc: EditText
    private lateinit var spDepto: Spinner
    private lateinit var tvAndv: TextView
    private lateinit var tvSmsOriginal: TextView
    private lateinit var tvTitulo: TextView
    private lateinit var btnEliminar: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_editar)
        db = TelefonosDb(this)

        tvTitulo = findViewById(R.id.text_titulo_form) as TextView
        etTrabajador = findViewById(R.id.et_trabajador) as EditText
        etCi = findViewById(R.id.et_ci) as EditText
        etCargo = findViewById(R.id.et_cargo) as EditText
        etNumero = findViewById(R.id.et_numero) as EditText
        etMarca = findViewById(R.id.et_marca) as EditText
        etModelo = findViewById(R.id.et_modelo) as EditText
        etImei = findViewById(R.id.et_imei) as EditText
        spTipo = findViewById(R.id.sp_tipo) as Spinner
        spInternet = findViewById(R.id.sp_internet) as Spinner
        etMinutos = findViewById(R.id.et_minutos) as EditText
        etMegas = findViewById(R.id.et_megas) as EditText
        etSmsPlan = findViewById(R.id.et_smsplan) as EditText
        etMac = findViewById(R.id.et_mac) as EditText
        etWifiIp = findViewById(R.id.et_wifiip) as EditText
        etSimIp = findViewById(R.id.et_simip) as EditText
        etSimPin = findViewById(R.id.et_spin) as EditText
        etSimPuk = findViewById(R.id.et_spuk) as EditText
        etDesc = findViewById(R.id.et_desc) as EditText
        spDepto = findViewById(R.id.sp_depto) as Spinner
        tvAndv = findViewById(R.id.tv_andv) as TextView
        tvSmsOriginal = findViewById(R.id.tv_sms_original) as TextView
        btnEliminar = findViewById(R.id.btn_eliminar) as Button

        numeroOriginal = intent.getStringExtra("numero") ?: ""
        cargar(numeroOriginal)

        (findViewById(R.id.btn_guardar) as Button).setOnClickListener { guardar() }
        btnEliminar.setOnClickListener { confirmarEliminar() }
    }

    /** Rellena el formulario con el telefono guardado (o lo deja vacio si es nuevo). */
    private fun cargar(numero: String) {
        depts = db.listarDepartamentos()

        // Spinner de departamento: opcion 0 = sin asignar, luego la lista maestra
        val opcionesDept = ArrayList<String>()
        opcionesDept.add(getString(R.string.spinner_sin_asignar))
        opcionesDept.addAll(depts)
        val adaptadorDept = ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, opcionesDept)
        adaptadorDept.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spDepto.adapter = adaptadorDept
        spDepto.setSelection(0)

        if (numero.isBlank()) {
            tvTitulo.text = getString(R.string.titulo_nuevo_telefono)
            btnEliminar.isEnabled = false
            return
        }

        val t = db.obtener(numero)
        if (t == null) {
            finish()
            return
        }
        tvTitulo.text = getString(R.string.titulo_editar_telefono, numero)

        etTrabajador.setText(t.trabajador)
        etCi.setText(t.ci)
        etCargo.setText(t.cargo)
        etNumero.setText(t.numero)
        etMarca.setText(t.marca)
        etModelo.setText(t.modelo)
        etImei.setText(t.imei)
        seleccionar(spTipo, t.tipo)
        seleccionar(spInternet, t.internet)
        etMinutos.setText(t.minutos)
        etMegas.setText(t.megas)
        etSmsPlan.setText(t.smsPlan)
        etMac.setText(t.mac)
        etWifiIp.setText(t.wifiIp)
        etSimIp.setText(t.simIp)
        etSimPin.setText(t.simPin)
        etSimPuk.setText(t.simPuk)
        etDesc.setText(t.desc)

        tvAndv.text = if (t.versionAndroid.isBlank()) "" else getString(R.string.version_android_guardada, t.versionAndroid)

        // Seleccionar el departamento actual si esta en la lista maestra
        var indice = 0
        for (i in depts.indices) {
            if (depts[i] == t.dept) indice = i + 1
        }
        spDepto.setSelection(indice)

        tvSmsOriginal.text = if (t.textoSms.isBlank()) "" else getString(R.string.sms_original) + "\n" + t.textoSms
    }

    /** Marca en un Spinner la opcion que coincide con el valor guardado. */
    private fun seleccionar(sp: Spinner, valor: String) {
        if (valor.isBlank()) {
            sp.setSelection(0)
            return
        }
        val posicion = (sp.adapter as? ArrayAdapter<String>)?.getPosition(valor) ?: -1
        sp.setSelection(if (posicion < 0) 0 else posicion)
    }

    /** Valor del Spinner: la opcion "—" equivale a vacío. */
    private fun valorSpinner(sp: Spinner): String {
        val v = (sp.selectedItem as? String) ?: return ""
        return if (v == "—") "" else v
    }

    private fun guardar() {
        val numero = SmsParser.normalizarNumero(etNumero.text.toString().trim())
        if (numero.length != 8) {
            Toast.makeText(this, getString(R.string.error_numero_invalido), Toast.LENGTH_LONG).show()
            return
        }

        val t = Telefono(numero = numero)
        t.trabajador = etTrabajador.text.toString().trim()
        t.ci = etCi.text.toString().trim()
        t.cargo = etCargo.text.toString().trim()
        t.marca = etMarca.text.toString().trim()
        t.modelo = etModelo.text.toString().trim()
        t.imei = etImei.text.toString().trim()
        t.tipo = valorSpinner(spTipo)
        t.internet = valorSpinner(spInternet)
        t.minutos = etMinutos.text.toString().trim()
        t.megas = etMegas.text.toString().trim()
        t.smsPlan = etSmsPlan.text.toString().trim()
        t.mac = etMac.text.toString().trim()
        t.wifiIp = etWifiIp.text.toString().trim()
        t.simIp = etSimIp.text.toString().trim()
        t.simPin = etSimPin.text.toString().trim()
        t.simPuk = etSimPuk.text.toString().trim()
        t.desc = etDesc.text.toString().trim()
        t.dept = if (spDepto.selectedItemPosition > 0) depts[spDepto.selectedItemPosition - 1] else ""
        t.editado = true

        // Conservar los datos que solo existen por el SMS (version Android, texto y fecha)
        val previo = if (numeroOriginal.isNotBlank()) db.obtener(numeroOriginal) else null
        if (previo != null) {
            t.versionAndroid = previo.versionAndroid
            t.textoSms = previo.textoSms
            t.fechaSms = previo.fechaSms
        }

        db.guardar(t)
        if (t.dept.isNotBlank()) db.agregarDepartamento(t.dept)
        if (numeroOriginal.isNotBlank() && numeroOriginal != numero) db.eliminar(numeroOriginal)

        Toast.makeText(this, getString(R.string.guardado_ok), Toast.LENGTH_SHORT).show()
        finish()
    }

    private fun confirmarEliminar() {
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.titulo_confirmar_eliminar))
            .setMessage(getString(R.string.mensaje_confirmar_eliminar, numeroOriginal))
            .setPositiveButton(getString(R.string.eliminar)) { _, _ ->
                db.eliminar(numeroOriginal)
                Toast.makeText(this, getString(R.string.eliminado_ok), Toast.LENGTH_SHORT).show()
                finish()
            }
            .setNegativeButton(getString(R.string.cancelar), null)
            .show()
    }
}
