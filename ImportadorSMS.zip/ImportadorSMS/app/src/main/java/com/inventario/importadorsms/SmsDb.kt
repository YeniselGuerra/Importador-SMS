package com.inventario.importadorsms

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

/**
 * Un mensaje SMS guardado en la base local de la app.
 */
data class SmsItem(
    val idLocal: Long,      // _id en la base local de esta app
    val idSistema: String,  // _id del mensaje en el sistema del telefono
    val tipo: String,       // RECIBIDO o ENVIADO
    val direccion: String,  // numero de telefono del remitente o destinatario
    val cuerpo: String,     // texto del mensaje
    val fechaUnix: Long,    // fecha en milisegundos desde 1970
    val leido: Boolean      // si estaba leido en el telefono
)

/**
 * Base de datos SQLite local donde quedan guardados todos los SMS importados.
 * Los mensajes no se duplican: cada uno tiene un identificador unico
 * (tipo + id del sistema) y los repetidos se ignoran al importar de nuevo.
 */
class SmsDb(context: Context) : SQLiteOpenHelper(context, NOMBRE_BD, null, VERSION_BD) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE sms (" +
                "_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "id_sistema TEXT NOT NULL, " +
                "tipo TEXT NOT NULL, " +
                "direccion TEXT NOT NULL, " +
                "cuerpo TEXT NOT NULL, " +
                "fecha INTEGER NOT NULL, " +
                "leido INTEGER NOT NULL DEFAULT 1, " +
                "importado_en INTEGER NOT NULL, " +
                "UNIQUE(tipo, id_sistema))"
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, versionVieja: Int, versionNueva: Int) {
        // Si en el futuro cambia la estructura, aqui se migran los datos.
        // Por ahora se recrea la tabla.
        db.execSQL("DROP TABLE IF EXISTS sms")
        onCreate(db)
    }

    /**
     * Inserta un mensaje nuevo. Si ya existe otro con el mismo tipo e
     * id del sistema lo ignora. Devuelve true si el mensaje era nuevo.
     */
    fun insertarSiNuevo(valores: ContentValues): Boolean {
        val db = writableDatabase
        val id = db.insertWithOnConflict("sms", null, valores, SQLiteDatabase.CONFLICT_IGNORE)
        return id != -1L
    }

    /** Cantidad total de mensajes guardados. */
    fun contar(): Int {
        val db = readableDatabase
        val cursor = db.rawQuery("SELECT COUNT(*) FROM sms", null)
        val total = if (cursor.moveToFirst()) cursor.getInt(0) else 0
        cursor.close()
        return total
    }

    /** Cantidad de mensajes de un tipo ("RECIBIDO" o "ENVIADO"). */
    fun contarPorTipo(tipo: String): Int {
        val db = readableDatabase
        val cursor = db.rawQuery("SELECT COUNT(*) FROM sms WHERE tipo = ?", arrayOf(tipo))
        val total = if (cursor.moveToFirst()) cursor.getInt(0) else 0
        cursor.close()
        return total
    }

    /** Devuelve los mensajes guardados, los mas recientes primero. */
    fun listarTodos(limite: Int = 5000): List<SmsItem> {
        val lista = ArrayList<SmsItem>()
        val db = readableDatabase
        val cursor = db.query(
            "sms",
            arrayOf("_id", "id_sistema", "tipo", "direccion", "cuerpo", "fecha", "leido"),
            null, null, null, null, "fecha DESC"
        )
        var cargados = 0
        while (cursor.moveToNext() && cargados < limite) {
            lista.add(
                SmsItem(
                    idLocal = cursor.getLong(0),
                    idSistema = cursor.getString(1) ?: "",
                    tipo = cursor.getString(2) ?: "",
                    direccion = cursor.getString(3) ?: "",
                    cuerpo = cursor.getString(4) ?: "",
                    fechaUnix = cursor.getLong(5),
                    leido = cursor.getInt(6) == 1
                )
            )
            cargados++
        }
        cursor.close()
        return lista
    }

    /** Todos los mensajes sin limite, para el XML de exportacion. */
    fun listarParaExportar(): List<SmsItem> = listarTodos(Int.MAX_VALUE)

    companion object {
        private const val NOMBRE_BD = "sms_importados.db"
        private const val VERSION_BD = 1
    }
}
