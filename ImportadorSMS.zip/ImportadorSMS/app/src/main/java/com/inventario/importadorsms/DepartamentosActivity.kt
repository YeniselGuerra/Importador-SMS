package com.inventario.importadorsms

import android.app.AlertDialog
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

/**
 * Gestion de la lista maestra de departamentos. Esta lista es la que viaja
 * en el XML exportado dentro de <departments> y es la misma que Factura
 * Aniel usa para agrupar los telefonos.
 */
class DepartamentosActivity : AppCompatActivity() {

    private lateinit var db: TelefonosDb
    private lateinit var lista: ListView
    private lateinit var tvEstado: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_departamentos)
        db = TelefonosDb(this)

        lista = findViewById(R.id.lista_deptos) as ListView
        tvEstado = findViewById(R.id.text_estado_deptos) as TextView

        (findViewById(R.id.btn_agregar_depto) as Button).setOnClickListener { agregar() }

        // Tocar un departamento pide confirmacion para eliminarlo
        lista.setOnItemClickListener { _, _, posicion, _ -> confirmarEliminar(posicion) }

        refrescar()
    }

    private fun refrescar() {
        val datos = db.listarDepartamentos()
        lista.adapter = ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, datos)
        tvEstado.text = getString(R.string.estado_deptos, datos.size)
    }

    private fun agregar() {
        val campo = findViewById(R.id.et_nuevo_depto) as EditText
        val nombre = campo.text.toString().trim()
        if (nombre.isBlank()) {
            Toast.makeText(this, getString(R.string.error_nombre_depto), Toast.LENGTH_SHORT).show()
            return
        }
        if (db.listarDepartamentos().contains(nombre)) {
            Toast.makeText(this, getString(R.string.depto_ya_existe, nombre), Toast.LENGTH_SHORT).show()
            return
        }
        db.agregarDepartamento(nombre)
        campo.setText("")
        refrescar()
    }

    private fun confirmarEliminar(posicion: Int) {
        val nombres = db.listarDepartamentos()
        if (posicion < 0 || posicion >= nombres.size) return
        val nombre = nombres[posicion]
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.titulo_confirmar_eliminar))
            .setMessage(getString(R.string.mensaje_confirmar_eliminar_depto, nombre))
            .setPositiveButton(getString(R.string.eliminar)) { _, _ ->
                db.eliminarDepartamento(nombre)
                refrescar()
            }
            .setNegativeButton(getString(R.string.cancelar), null)
            .show()
    }
}
