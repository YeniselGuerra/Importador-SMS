package com.inventario.importadorsms

/**
 * Extrae los datos de telefono de un SMS de inventario enviado por la app
 * InventarioTelefonos. Acepta sus dos formatos:
 *
 * Compacto (una linea):
 *   INV|TRAB:...|CI:...|CARGO:...|TIPO:...|MARCA:...|MODELO:...|ANDV:...|TEL:...|
 *   IMEI:...|MAC:...|WIP:...|SIP:...|NET:...|MIN:...|MB:...|PIN:...|PUK:...
 *
 * Detallado (una linea por campo):
 *   INV - Inventario de telefono
 *   Trabajador: ...
 *   CI: ...
 *   ...
 */
object SmsParser {

    /** Claves de campo que identifican que un SMS es un inventario. */
    private val CLAVES_DATO = setOf(
        "TRAB", "TRABAJADOR", "CI", "CARGO", "TIPO", "MARCA", "MODELO",
        "ANDV", "TEL", "TELEFONO", "NO. TELEFONO", "IMEI", "MAC", "WIP",
        "SIP", "NET", "MIN", "MB", "PIN", "PUK"
    )

    /** Quita acentos para comparar claves sin importar como se escriban. */
    private fun quitarAcentos(s: String): String {
        val sb = StringBuilder(s.length)
        for (c in s) {
            when (c) {
                'á', 'à', 'ä' -> sb.append('a')
                'é', 'è', 'ë' -> sb.append('e')
                'í', 'ì', 'ï' -> sb.append('i')
                'ó', 'ò', 'ö' -> sb.append('o')
                'ú', 'ù', 'ü' -> sb.append('u')
                'Á', 'À', 'Ä' -> sb.append('A')
                'É', 'È', 'Ë' -> sb.append('E')
                'Í', 'Ì', 'Ï' -> sb.append('I')
                'Ó', 'Ò', 'Ö' -> sb.append('O')
                'Ú', 'Ù', 'Ü' -> sb.append('U')
                else -> sb.append(c)
            }
        }
        return sb.toString()
    }

    /** Normaliza un numero al formato de 8 dígitos que usa Factura Aniel. */
    fun normalizarNumero(bruto: String): String {
        val digitos = bruto.filter { it.isDigit() }
        return if (digitos.length >= 8) digitos.substring(digitos.length - 8) else digitos
    }

    private fun normalizarTipo(valor: String): String {
        val s = quitarAcentos(valor.trim()).lowercase()
        return when (s) {
            "corporativo" -> "Corporativo"
            "privado" -> "Privado"
            else -> valor.trim()
        }
    }

    /** El SMS viaja como SI/NO; Factura Aniel usa Si/No con acento. */
    private fun normalizarSiNo(valor: String): String {
        val s = quitarAcentos(valor.trim()).uppercase()
        return when (s) {
            "SI", "S" -> "Sí"
            "NO", "N" -> "No"
            else -> valor.trim()
        }
    }

    /**
     * Devuelve un Telefono con los datos del SMS (numero puede venir vacío
     * si el mensaje no trae TEL; en ese caso el importador usa el remitente).
     * Devuelve null si el texto no es un SMS de inventario.
     */
    fun parsear(texto: String): Telefono? {
        val limpio = texto.trim()
        if (!quitarAcentos(limpio).uppercase().startsWith("INV")) return null

        val t = Telefono(numero = "")
        var hayDatos = false

        val pares = if (limpio.contains("|")) limpio.split("|") else limpio.split("\n")
        for (parte in pares) {
            val dosPuntos = parte.indexOf(':')
            if (dosPuntos <= 0) continue
            val clave = quitarAcentos(parte.substring(0, dosPuntos).trim()).uppercase()
            val valor = parte.substring(dosPuntos + 1).trim()
            if (clave == "INV" || valor.isEmpty()) continue
            if (asignar(t, clave, valor)) hayDatos = true
        }

        if (!hayDatos) return null
        if (t.numero.isNotBlank()) t.numero = normalizarNumero(t.numero)
        return t
    }

    /** Aplica un par clave:valor; devuelve true si la clave era de datos. */
    private fun asignar(t: Telefono, clave: String, valor: String): Boolean {
        when (clave) {
            "TRAB", "TRABAJADOR" -> t.trabajador = valor
            "CI", "CARNET" -> t.ci = valor
            "CARGO" -> t.cargo = valor
            "TIPO" -> t.tipo = normalizarTipo(valor)
            "MARCA" -> t.marca = valor
            "MODELO" -> t.modelo = valor
            "ANDV", "VERSION ANDROID" -> t.versionAndroid = valor
            "TEL", "TELEFONO", "NO. TELEFONO", "NO TELEFONO" -> t.numero = valor
            "IMEI" -> t.imei = valor
            "MAC" -> t.mac = valor
            "WIP", "WIFI IP" -> t.wifiIp = valor
            "SIP", "SIM IP" -> t.simIp = valor
            "NET", "INTERNET" -> t.internet = normalizarSiNo(valor)
            "MIN", "MINUTOS" -> t.minutos = valor
            "MB", "MEGAS" -> t.megas = valor
            "PIN", "PIN SIM" -> t.simPin = valor
            "PUK", "PUK SIM" -> t.simPuk = valor
            else -> return false
        }
        return true
    }
}
