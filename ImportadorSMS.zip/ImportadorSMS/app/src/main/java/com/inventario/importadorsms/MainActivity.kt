package com.inventario.importadorsms

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import java.io.File

/**
 * Pantalla principal de Importador SMS, companera de la pestaña
 * "Base de Datos de Telefonos" de Factura Aniel:
 *  1. Importar SMS: lee los mensajes con inventario (formato INV) y guarda
 *     o completa cada telefono en la base local.
 *  2. Lista editable: tocar un telefono abre la pantalla de edicion con
 *     todos los campos (trabajador, CI, equipo, plan, SIM, departamento...).
 *  3. Agregar telefono manualmente y gestionar departamentos.
 *  4. Exportar XML: genera base_telefonos_etecsa_...xml en Descargas, con el
 *     mismo formato que Factura Aniel importa con "Importar BD (XML)".
 */
class MainActivity : AppCompatActivity() {

    private lateinit var textoEstado: TextView
    private lateinit var textoRuta: TextView
    private lateinit var lista: ListView
    private lateinit var adaptador: TelefonosListAdapter
    private lateinit var db: TelefonosDb

    // Ultima exportacion: uri de MediaStore (Android 10+) o archivo (Android 9 o menos)
    private var uriUltima: Uri? = null
    private var archivoUltimo: File? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        db = TelefonosDb(this)
        textoEstado = findViewById(R.id.text_estado) as TextView
        textoRuta = findViewById(R.id.text_ruta) as TextView
        lista = findViewById(R.id.lista) as ListView

        adaptador = TelefonosListAdapter(this)
        lista.adapter = adaptador

        (findViewById(R.id.btn_importar) as Button).setOnClickListener { pedirPermisoEImportar() }
        (findViewById(R.id.btn_agregar) as Button).setOnClickListener { abrirEditor("") }
        (findViewById(R.id.btn_departamentos) as Button).setOnClickListener {
            startActivity(Intent(this, DepartamentosActivity::class.java))
        }
        (findViewById(R.id.btn_exportar) as Button).setOnClickListener { pedirPermisoYExportar() }
        (findViewById(R.id.btn_compartir) as Button).setOnClickListener { compartirUltimo() }

        // Tocar un telefono abre la pantalla de edicion
        lista.setOnItemClickListener { _, _, posicion, _ ->
            val t = adaptador.getItem(posicion) as Telefono
            abrirEditor(t.numero)
        }
    }

    override fun onResume() {
        super.onResume()
        refrescar()
    }

    /** Actualiza el contador de la base y el listado en pantalla. */
    private fun refrescar() {
        val total = db.contar()
        val deptos = db.contarDepartamentos()
        val sinDepto = db.contarSinDepartamento()
        textoEstado.text = getString(R.string.estado_bd, total, deptos, sinDepto)
        Thread {
            val datos = db.listar()
            runOnUiThread { adaptador.reemplazar(datos) }
        }.start()
    }

    private fun abrirEditor(numero: String) {
        val intent = Intent(this, EditarTelefonoActivity::class.java)
        intent.putExtra("numero", numero)
        startActivity(intent)
    }

    // ---------- Importacion de SMS ----------

    private fun tienePermisoSms(): Boolean =
        ContextCompat.checkSelfPermission(this, Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED

    private fun pedirPermisoEImportar() {
        if (tienePermisoSms()) {
            importar()
        } else {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.READ_SMS), CODIGO_PERMISO_SMS)
        }
    }

    private fun importar() {
        (findViewById(R.id.btn_importar) as Button).isEnabled = false
        textoEstado.text = getString(R.string.importando)
        Thread {
            var resultado: SmsImporter.Resultado? = null
            var mensajeError = ""
            try {
                resultado = SmsImporter.importar(this)
            } catch (e: Exception) {
                mensajeError = e.message ?: ""
            }
            runOnUiThread {
                (findViewById(R.id.btn_importar) as Button).isEnabled = true
                if (resultado == null) {
                    Toast.makeText(this, getString(R.string.importacion_error, mensajeError), Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(this, getString(R.string.importacion_resultado,
                        resultado.nuevos, resultado.actualizados, resultado.sinDatos, resultado.errores),
                        Toast.LENGTH_LONG).show()
                }
                refrescar()
            }
        }.start()
    }

    // ---------- Exportacion ----------

    private fun pedirPermisoYExportar() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            exportar()
            return
        }
        val permiso = Manifest.permission.WRITE_EXTERNAL_STORAGE
        if (ContextCompat.checkSelfPermission(this, permiso) == PackageManager.PERMISSION_GRANTED) {
            exportar()
        } else {
            ActivityCompat.requestPermissions(this, arrayOf(permiso), CODIGO_PERMISO_ESCRITURA)
        }
    }

    private fun exportar() {
        (findViewById(R.id.btn_exportar) as Button).isEnabled = false
        (findViewById(R.id.btn_importar) as Button).isEnabled = false
        textoEstado.text = getString(R.string.exportando)
        Thread {
            var exportado: XmlExporter.Exportado? = null
            var mensajeError = ""
            try {
                exportado = XmlExporter.exportar(this)
            } catch (e: Exception) {
                mensajeError = e.message ?: ""
            }
            runOnUiThread {
                (findViewById(R.id.btn_exportar) as Button).isEnabled = true
                (findViewById(R.id.btn_importar) as Button).isEnabled = true
                if (exportado != null) {
                    uriUltima = exportado.uri
                    archivoUltimo = exportado.archivo
                    val ruta = exportado.uri?.toString() ?: exportado.archivo?.absolutePath ?: ""
                    textoRuta.text = getString(R.string.ruta_exportacion, ruta)
                    Toast.makeText(this, getString(R.string.exportacion_ok), Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(this, getString(R.string.exportacion_error, mensajeError), Toast.LENGTH_LONG).show()
                }
                refrescar()
            }
        }.start()
    }

    /** Comparte el XML de la ultima exportacion con cualquier app instalada. */
    private fun compartirUltimo() {
        if (uriUltima == null && archivoUltimo == null) {
            Toast.makeText(this, getString(R.string.compartir_sin_archivo), Toast.LENGTH_SHORT).show()
            return
        }
        val uri = uriUltima
            ?: FileProvider.getUriForFile(this, "com.inventario.importadorsms.fileprovider", archivoUltimo!!)

        val intent = Intent(Intent.ACTION_SEND)
        intent.type = "application/xml"
        intent.putExtra(Intent.EXTRA_STREAM, uri)
        intent.putExtra(Intent.EXTRA_SUBJECT, getString(R.string.compartir_asunto))
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startActivity(Intent.createChooser(intent, getString(R.string.compartir_titulo)))
    }

    // ---------- Respuesta a los permisos ----------

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == CODIGO_PERMISO_SMS) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                importar()
            } else {
                textoEstado.text = getString(R.string.permiso_denegado)
                Toast.makeText(this, getString(R.string.permiso_denegado), Toast.LENGTH_LONG).show()
            }
        }
        if (requestCode == CODIGO_PERMISO_ESCRITURA) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                exportar()
            } else {
                Toast.makeText(this, getString(R.string.permiso_escritura_denegado), Toast.LENGTH_LONG).show()
            }
        }
    }

    companion object {
        private const val CODIGO_PERMISO_SMS = 101
        private const val CODIGO_PERMISO_ESCRITURA = 102
    }
}
