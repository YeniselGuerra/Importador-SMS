package com.inventario.importadorsms

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import java.io.File

/**
 * Pantalla principal de Importador SMS:
 *  1. Importar: lee todos los SMS del telefono (recibidos y enviados)
 *     y los guarda en la base local, sin duplicar los ya importados.
 *  2. Listar: muestra los mensajes guardados, los mas recientes primero.
 *  3. Exportar: genera un XML con todo y lo guarda en la carpeta Descargas.
 *  4. Compartir: envia el ultimo XML por cualquier app instalada.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var textoEstado: TextView
    private lateinit var textoRuta: TextView
    private lateinit var btnImportar: Button
    private lateinit var btnExportar: Button
    private lateinit var btnCompartir: Button
    private lateinit var lista: ListView
    private lateinit var adaptador: SmsListAdapter
    private lateinit var db: SmsDb

    // Ultima exportacion: uri de MediaStore (Android 10+) o archivo (Android 9 o menos)
    private var uriUltima: Uri? = null
    private var archivoUltimo: File? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        db = SmsDb(this)
        textoEstado = findViewById(R.id.text_estado) as TextView
        textoRuta = findViewById(R.id.text_ruta) as TextView
        btnImportar = findViewById(R.id.btn_importar) as Button
        btnExportar = findViewById(R.id.btn_exportar) as Button
        btnCompartir = findViewById(R.id.btn_compartir) as Button
        lista = findViewById(R.id.lista) as ListView

        adaptador = SmsListAdapter(this)
        lista.adapter = adaptador

        btnImportar.setOnClickListener { pedirPermisoEImportar() }
        btnExportar.setOnClickListener { pedirPermisoYExportar() }
        btnCompartir.setOnClickListener { compartirUltimo() }
    }

    override fun onResume() {
        super.onResume()
        refrescar()
    }

    /** Actualiza el contador de la base y el listado en pantalla. */
    private fun refrescar() {
        val total = db.contar()
        val recibidos = db.contarPorTipo(SmsImporter.TIPO_RECIBIDO)
        val enviados = db.contarPorTipo(SmsImporter.TIPO_ENVIADO)
        textoEstado.text = getString(R.string.estado_bd, total, recibidos, enviados)
        Thread {
            val datos = db.listarTodos()
            runOnUiThread { adaptador.reemplazar(datos) }
        }.start()
    }

    // ---------- Importacion ----------

    private fun tienePermisoSms(): Boolean =
        ContextCompat.checkSelfPermission(this, Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED

    private fun pedirPermisoEImportar() {
        if (tienePermisoSms()) {
            importar()
        } else {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.READ_SMS), CODIGO_PERMISO_SMS)
        }
    }

    private fun importar() {
        btnImportar.isEnabled = false
        textoEstado.text = getString(R.string.importando)
        Thread {
            var resultado: SmsImporter.Resultado? = null
            var mensajeError = ""
            try {
                resultado = SmsImporter.importar(this)
            } catch (e: Exception) {
                mensajeError = e.message ?: ""
            }
            runOnUiThread {
                btnImportar.isEnabled = true
                if (resultado == null) {
                    Toast.makeText(this, getString(R.string.importacion_error, mensajeError), Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(
                        this,
                        getString(
                            R.string.importacion_resultado,
                            resultado.nuevosRecibidos,
                            resultado.nuevosEnviados,
                            resultado.yaGuardados,
                            resultado.errores
                        ),
                        Toast.LENGTH_LONG
                    ).show()
                }
                refrescar()
            }
        }.start()
    }

    // ---------- Exportacion ----------

    private fun pedirPermisoYExportar() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            exportar()
            return
        }
        val permiso = Manifest.permission.WRITE_EXTERNAL_STORAGE
        if (ContextCompat.checkSelfPermission(this, permiso) == PackageManager.PERMISSION_GRANTED) {
            exportar()
        } else {
            ActivityCompat.requestPermissions(this, arrayOf(permiso), CODIGO_PERMISO_ESCRITURA)
        }
    }

    private fun exportar() {
        btnExportar.isEnabled = false
        btnImportar.isEnabled = false
        textoEstado.text = getString(R.string.exportando)
        Thread {
            var exportado: XmlExporter.Exportado? = null
            var mensajeError = ""
            try {
                exportado = XmlExporter.exportar(this)
            } catch (e: Exception) {
                mensajeError = e.message ?: ""
            }
            runOnUiThread {
                btnExportar.isEnabled = true
                btnImportar.isEnabled = true
                if (exportado != null) {
                    uriUltima = exportado.uri
                    archivoUltimo = exportado.archivo
                    val ruta = exportado.uri?.toString() ?: exportado.archivo?.absolutePath ?: ""
                    textoRuta.text = getString(R.string.ruta_exportacion, ruta)
                    Toast.makeText(this, getString(R.string.exportacion_ok), Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(this, getString(R.string.exportacion_error, mensajeError), Toast.LENGTH_LONG).show()
                }
                refrescar()
            }
        }.start()
    }

    /** Comparte el XML de la ultima exportacion con cualquier app instalada. */
    private fun compartirUltimo() {
        if (uriUltima == null && archivoUltimo == null) {
            Toast.makeText(this, getString(R.string.compartir_sin_archivo), Toast.LENGTH_SHORT).show()
            return
        }
        val uri = uriUltima
            ?: FileProvider.getUriForFile(this, "com.inventario.importadorsms.fileprovider", archivoUltimo!!)

        val intent = Intent(Intent.ACTION_SEND)
        intent.type = "application/xml"
        intent.putExtra(Intent.EXTRA_STREAM, uri)
        intent.putExtra(Intent.EXTRA_SUBJECT, getString(R.string.compartir_asunto))
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startActivity(Intent.createChooser(intent, getString(R.string.compartir_titulo)))
    }

    // ---------- Respuesta a los permisos ----------

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == CODIGO_PERMISO_SMS) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                importar()
            } else {
                textoEstado.text = getString(R.string.permiso_denegado)
                Toast.makeText(this, getString(R.string.permiso_denegado), Toast.LENGTH_LONG).show()
            }
        }
        if (requestCode == CODIGO_PERMISO_ESCRITURA) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                exportar()
            } else {
                Toast.makeText(this, getString(R.string.permiso_escritura_denegado), Toast.LENGTH_LONG).show()
            }
        }
    }

    companion object {
        private const val CODIGO_PERMISO_SMS = 101
        private const val CODIGO_PERMISO_ESCRITURA = 102
    }
}
