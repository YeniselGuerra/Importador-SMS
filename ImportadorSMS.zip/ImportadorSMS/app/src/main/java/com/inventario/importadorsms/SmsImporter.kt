package com.inventario.importadorsms

import android.content.Context
import android.net.Uri

/**
 * Lee los SMS del telefono (bandeja de entrada y enviados), extrae los que
 * son inventarios en formato INV (los que envia InventarioTelefonos) y
 * guarda o completa cada telefono en la base local. Los demas mensajes
 * (chats, notificaciones, etc.) se ignoran sin error.
 */
object SmsImporter {

    data class Resultado(
        val nuevos: Int,
        val actualizados: Int,
        val sinDatos: Int,
        val errores: Int
    )

    fun importar(context: Context): Resultado {
        val db = TelefonosDb(context)
        var nuevos = 0
        var actualizados = 0
        var sinDatos = 0
        var errores = 0

        // La bandeja de entrada es donde llegan los inventarios; los enviados
        // tambien se revisan por si el telefono receptor fue el emisor.
        val consultas = listOf(
            Pair("content://sms/inbox", "RECIBIDO"),
            Pair("content://sms/sent", "ENVIADO")
        )

        for (consulta in consultas) {
            val uri = Uri.parse(consulta.first)
            try {
                val cursor = context.contentResolver.query(
                    uri,
                    arrayOf("_id", "address", "body", "date"),
                    null, null, "date ASC"
                )
                if (cursor == null) {
                    errores++
                    continue
                }
                cursor.use {
                    while (it.moveToNext()) {
                        try {
                            val cuerpo = it.getString(2) ?: ""
                            val parseado = SmsParser.parsear(cuerpo)
                            if (parseado == null) {
                                sinDatos++
                                continue
                            }
                            parseado.textoSms = cuerpo
                            parseado.fechaSms = it.getLong(3)
                            if (parseado.numero.isBlank()) {
                                // Sin TEL en el mensaje: usa el numero del remitente
                                parseado.numero = SmsParser.normalizarNumero(it.getString(1) ?: "")
                            }
                            if (parseado.numero.length != 8) {
                                sinDatos++
                                continue
                            }
                            when (db.guardarDesdeSms(parseado)) {
                                TelefonosDb.NUEVO -> nuevos++
                                else -> actualizados++
                            }
                        } catch (e: Exception) {
                            errores++
                        }
                    }
                }
            } catch (e: Exception) {
                errores++
            }
        }

        db.close()
        return Resultado(nuevos, actualizados, sinDatos, errores)
    }
}
