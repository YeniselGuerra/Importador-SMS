package com.inventario.importadorsms

import android.content.ContentValues
import android.content.Context
import android.net.Uri

/**
 * Lee todos los SMS del telefono (recibidos y enviados) usando el proveedor
 * de mensajes del sistema y los guarda en la base local. Los que ya estaban
 * guardados se ignoran, asi que se puede importar varias veces sin duplicar.
 *
 * Requiere el permiso READ_SMS concedido por el usuario.
 */
object SmsImporter {

    /** Tipos de mensaje que maneja la app. */
    const val TIPO_RECIBIDO = "RECIBIDO"
    const val TIPO_ENVIADO = "ENVIADO"

    /** Resumen de una importacion. */
    data class Resultado(
        val nuevosRecibidos: Int,
        val nuevosEnviados: Int,
        val yaGuardados: Int,
        val errores: Int
    )

    fun importar(context: Context): Resultado {
        val db = SmsDb(context)
        val ahora = System.currentTimeMillis()
        var nuevosRecibidos = 0
        var nuevosEnviados = 0
        var yaGuardados = 0
        var errores = 0

        // Cada consulta: uri del proveedor y tipo que se le asigna
        val consultas = listOf(
            Pair("content://sms/inbox", TIPO_RECIBIDO),
            Pair("content://sms/sent", TIPO_ENVIADO)
        )

        for (consulta in consultas) {
            val uri = Uri.parse(consulta.first)
            val tipo = consulta.second
            try {
                val cursor = context.contentResolver.query(
                    uri,
                    arrayOf("_id", "address", "body", "date", "read"),
                    null, null, "date DESC"
                )
                if (cursor == null) {
                    errores++
                    continue
                }
                cursor.use {
                    while (it.moveToNext()) {
                        try {
                            val valores = ContentValues()
                            valores.put("id_sistema", it.getString(0) ?: "")
                            valores.put("tipo", tipo)
                            valores.put("direccion", it.getString(1) ?: "")
                            valores.put("cuerpo", it.getString(2) ?: "")
                            valores.put("fecha", it.getLong(3))
                            valores.put("leido", if (it.getInt(4) == 1) 1 else 0)
                            valores.put("importado_en", ahora)
                            if (db.insertarSiNuevo(valores)) {
                                if (tipo == TIPO_RECIBIDO) nuevosRecibidos++ else nuevosEnviados++
                            } else {
                                yaGuardados++
                            }
                        } catch (e: Exception) {
                            errores++
                        }
                    }
                }
            } catch (e: Exception) {
                errores++
            }
        }

        db.close()
        return Resultado(nuevosRecibidos, nuevosEnviados, yaGuardados, errores)
    }
}
