# Reglas de ProGuard/R8. La variante release se genera sin ofuscar
# (minifyEnabled false), por lo que estas reglas son solo preventivas.
-keep class com.inventario.telefonos.** { *; }
