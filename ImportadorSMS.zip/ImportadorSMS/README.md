# Importador SMS

Aplicación Android compañera de **Factura Aniel** (la página "ETECSA - Facturas a Excel"). Esta app recoge del teléfono los SMS de inventario que envía la app **InventarioTelefonos**, los convierte en una **base de datos de teléfonos editable** (trabajador, CI, cargo, equipo, plan, SIM y departamento), y al terminar la **exporta a XML exactamente en el formato que la pestaña "Base de Datos de Teléfonos" de Factura Aniel importa con el botón "Importar BD (XML)"**.

Todo lo que se importa queda guardado en la base local `telefonos.db` de la app: se puede cerrar, revisar, corregir a mano y volver a exportar cuando haga falta.

## 1. Qué hace la aplicación

La pantalla principal tiene cinco botones y la lista de teléfonos:

| Botón | Acción |
|-------|--------|
| **Importar SMS del teléfono** | Pide el permiso de SMS (la primera vez) y lee la bandeja de entrada y los enviados. Detecta los mensajes con inventario en formato `INV` (los que envía InventarioTelefonos), extrae los datos de cada teléfono y los guarda o completa. Los demás mensajes (chats, notificaciones) se ignoran. |
| **Agregar teléfono manualmente** | Abre el formulario vacío para dar de alta un teléfono a mano (con o sin SMS de origen). |
| **Departamentos** | Gestiona la lista de departamentos (agregar y eliminar). Esta lista viaja en el XML dentro de `<departments>`. |
| **Exportar XML para Factura Aniel** | Genera `base_telefonos_etecsa_FECHA_HORA.xml` en la carpeta **Descargas**, en el mismo formato `etecsa_db` que genera la propia Factura Aniel con "Exportar BD (XML)". |
| **Compartir el último XML** | Abre el menú de compartir de Android (Drive, correo, WhatsApp, etc.) con el último XML exportado, para pasarlo a la PC. |

La lista muestra cada teléfono con su número, trabajador, marca/modelo, IMEI, departamento y la fecha del SMS de origen. **Tocar un teléfono abre el formulario de edición**, con todos los campos que maneja Factura Aniel: trabajador, CI, cargo, número (8 dígitos), marca, modelo, IMEI, tipo (Corporativo/Privado), acceso a Internet, minutos, megas, SMS del plan, MAC, WIFI IP, SIM IP, PIN, PUK, descripción y departamento. Desde el formulario también se puede **eliminar** el teléfono (con confirmación).

El formulario muestra además dos datos de referencia que llegan por SMS y no se exportan: la versión de Android reportada y el **mensaje SMS original** completo, para poder verificar los datos contra lo que envió el trabajador.

## 2. Flujo de trabajo completo

1. Los trabajadores levantan el inventario con la app **InventarioTelefonos** y envían el SMS al teléfono central.
2. En el teléfono central se abre **Importador SMS** → **Importar SMS del teléfono**. La app reconoce los mensajes `INV|...`, crea un registro por teléfono y completa los campos (marca, modelo, IMEI, CI, cargo, tipo, plan, MAC, IPs, PIN/PUK...).
3. Se revisa la lista: se toca cada teléfono para **corregir o completar** lo que falte (por ejemplo, el PIN de la SIM, que nunca viaja por SMS si el trabajador no lo escribió) y asignar el **departamento** de cada teléfono.
4. Cuando todo está listo: **Exportar XML para Factura Aniel** → el archivo queda en **Descargas**.
5. Se pasa el XML a la PC (o se comparte directo) y en Factura Aniel: pestaña **Base de Datos de Teléfonos** → **Importar BD (XML)**.

## 3. Cómo rellena los datos (formato INV)

La app reconoce los dos formatos que envía InventarioTelefonos:

**Compacto (una línea):**

```
INV|TRAB:Aniel Pérez|CI:85061212345|CARGO:Especialista|TIPO:Corporativo|MARCA:Samsung|MODELO:Galaxy A52|ANDV:13|TEL:60946232|IMEI:356938035643809|MAC:AA:BB:CC:DD:EE:FF|WIP:192.168.1.45|SIP:10.40.12.33|NET:SI|MIN:200|MB:4096|PIN:1234|PUK:12345678|
```

**Detallado (una línea por campo):**

```
INV - Inventario de teléfono
Trabajador: Aniel Pérez
CI: 85061212345
...
No. Teléfono: 60946232
IMEI: 356938035643809
...
```

Equivalencia de claves del SMS con los campos de la base:

| Clave SMS | Campo de la BD | Nota |
|-----------|----------------|------|
| `TEL` | number | Se normaliza a los últimos 8 dígitos (admite `+53`); si falta, se usa el número del remitente del SMS |
| `TRAB` | trabajador | |
| `CI` | ci | |
| `CARGO` | cargo | |
| `TIPO` | tipo | Se normaliza a Corporativo/Privado |
| `MARCA`, `MODELO` | marca, modelo | |
| `IMEI` | imei | |
| `MAC`, `WIP`, `SIP` | mac, wifi_ip, sim_ip | |
| `NET` | internet | `SI`→`Sí`, `NO`→`No` (igual que Factura Aniel) |
| `MIN`, `MB` | minutos, megas | |
| `PIN`, `PUK` | sim_pin, sim_puk | |
| `ANDV` | (solo referencia) | Factura Aniel no tiene ese campo; se muestra en el formulario |
| — | dept | No viaja por SMS: se asigna en la app |
| — | sms (plan) | No viaja por SMS: se escribe a mano si hace falta |
| — | desc | Se escribe a mano |

Reglas de seguridad al importar: un teléfono **nuevo** se crea con los datos del SMS; un teléfono que **ya existe** solo completa los campos que están **vacíos** — nunca pisa lo corregido a mano. Se puede importar varias veces sin duplicar registros.

## 4. Formato del XML exportado

El XML es el mismo que Factura Aniel genera y espera (`buildDatabaseXML` / `importDatabase`):

```xml
<?xml version="1.0" encoding="UTF-8"?>
<etecsa_db>
  <departments>
    <dept>Agropecuario</dept>
    <dept>Dirección</dept>
  </departments>
  <phones>
    <phone number="60946232" dept="Agropecuario" trabajador="Aniel Pérez" ci="85061212345" cargo="Especialista" marca="Samsung" modelo="Galaxy A52" imei="356938035643809" internet="Sí" minutos="200" megas="4096" sms="" mac="AA:BB:CC:DD:EE:FF" wifi_ip="192.168.1.45" tipo="Corporativo" sim_ip="10.40.12.33" sim_pin="1234" sim_puk="12345678">Oficina del director</phone>
  </phones>
</etecsa_db>
```

Tres reglas que la app ya cumple (y conviene conocer):

- **El atributo `dept` es obligatorio**: Factura Aniel descarta cualquier `<phone>` sin departamento. Los teléfonos que no se asignaron se exportan con `dept="Sin Asignar"`, que es exactamente como Factura Aniel agrupa a los no asignados.
- **La lista `<departments>` se reemplaza** al importar: la lista de departamentos que se exporta es la de la app, así que manténla completa (pantalla "Departamentos") antes de exportar.
- La **descripción** viaja como contenido del elemento `<phone>`, no como atributo (así lo hace Factura Aniel).

## 5. Instalación y permisos

Instale el APK (ver sección 6) y ábralo. Al pulsar **Importar SMS** por primera vez, Android pedirá el permiso **SMS**: acéptelo, es necesario para leer los mensajes. Si lo rechaza, se puede conceder después en **Ajustes → Aplicaciones → Importador SMS → Permisos → SMS**.

- En **Android 10 o superior** no se pide ningún permiso más: el XML se guarda en Descargas sin permisos adicionales.
- En **Android 9 o anterior** se pide además el permiso de **almacenamiento** al exportar.

Nota: Google Play restringe las apps que piden permiso de SMS, pero esta aplicación se instala directamente con el APK (fuera de Play), donde el permiso funciona con normalidad. No es necesario que la app sea la aplicación de SMS predeterminada para leer los mensajes.

## 6. Cómo compilar el APK

### Opción A — Android Studio

1. **File → Open** y seleccione la carpeta `ImportadorSMS`.
2. Espere la sincronización de Gradle (la primera vez descarga dependencias).
3. **Build → Build Bundle(s)/APK(s) → Build APK(s)**.
4. El APK queda en `app/build/outputs/apk/debug/app-debug.apk`.

### Opción B — Línea de comandos

Requisitos: JDK 11 o 17 y conectividad para descargar Gradle 7.6.4 y las librerías.

```bash
cd ImportadorSMS
./gradlew assembleDebug        # Linux/Mac
gradlew.bat assembleDebug      # Windows
```

### Opción C — Compilar online gratis con GitHub Actions (sin instalar nada)

Igual que con la app anterior. **Son dos subidas la primera vez**, porque GitHub no mira dentro de los ZIP:

1. **New repository** → nombre `importador-sms` → visibilidad **Public** → **Create repository**.
2. Pulse **"uploading an existing file"**, arrastre el archivo `ImportadorSMS.zip` → **Commit changes**.
3. **Add file → Create new file** → como nombre escriba `.github/workflows/build-apk.yml` → pegue el YAML de abajo → **Commit changes**.
4. La pestaña **Actions** mostrará "Compilar APK" en ejecución (5–15 minutos).
5. Al terminar (✔ verde), entre en la ejecución y baje a **Artifacts**: descargue `ImportadorSMS-apk`, que contiene `ImportadorSMS.apk`.
6. Pase el APK al teléfono e instale aceptando "fuentes desconocidas".

**Si ya creó el repositorio con el workflow la vez anterior**: solo suba el ZIP nuevo (**Add file → upload**) y la compilación arranca sola.

```yaml
name: Compilar APK

on:
  push:
  workflow_dispatch:

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - name: Descargar el repositorio
        uses: actions/checkout@v5

      - name: Instalar Java 17 (Temurin)
        uses: actions/setup-java@v5
        with:
          distribution: temurin
          java-version: '17'

      - name: Descomprimir el proyecto
        run: |
          Z=$(ls *.zip | head -n1)
          echo "Descomprimiendo $Z"
          unzip -oq "$Z"

      - name: Compilar APK (debug)
        working-directory: ImportadorSMS
        run: |
          set -o pipefail
          chmod +x gradlew
          ./gradlew assembleDebug --no-daemon 2>&1 | tee /tmp/build.log

      - name: Mostrar el error en el resumen (solo si falla)
        if: failure()
        run: |
          {
            echo "### Qué falló en la compilación (últimas 60 líneas)"
            echo ''
            echo '```text'
            tail -n 60 /tmp/build.log | sed -e 's/\x1b\[[0-9;]*m//g'
            echo '```'
          } >> "$GITHUB_STEP_SUMMARY" 2>/dev/null || true

      - name: Guardar el log completo (solo si falla)
        if: failure()
        uses: actions/upload-artifact@v4
        with:
          name: log-fallo
          path: /tmp/build.log

      - name: Renombrar el APK
        if: success()
        working-directory: ImportadorSMS
        run: cp app/build/outputs/apk/debug/app-debug.apk ImportadorSMS.apk

      - name: Publicar el APK como artefacto
        if: success()
        uses: actions/upload-artifact@v4
        with:
          name: ImportadorSMS-apk
          path: ImportadorSMS/ImportadorSMS.apk
```

### Compatibilidad de versiones

| Componente | Versión usada |
|------------|---------------|
| Gradle | 7.6.4 (el wrapper lo descarga solo) |
| Android Gradle Plugin | 7.4.2 |
| Kotlin | 1.8.22 |
| compileSdk / targetSdk | 33 |
| minSdk | 21 (Android 5.0 en adelante) |

## 7. Notas técnicas

- **Base local**: SQLite (`telefonos.db`) con dos tablas: `telefonos` (clave = número de 8 dígitos, la misma que Factura Aniel) y `departamentos` (lista maestra con orden). La lectura e importación ocurren en un hilo aparte para no bloquear la pantalla.
- **Fuente de datos**: el proveedor de SMS del sistema (`content://sms/inbox` y `content://sms/sent`), columnas estándar (`_id`, `address`, `body`, `date`) presentes en Android 5 o superior.
- **Parser**: reconoce ambos formatos de InventarioTelefonos, compara las claves sin distinguir mayúsculas ni acentos, tolera MAC con `:` dentro del valor y numera los teléfonos a 8 dígitos.
- **Archivos exportados**: `base_telefonos_etecsa_AAAAMMDD_HHMMSS.xml` en Descargas; cada exportación crea un archivo nuevo con fecha en el nombre, nunca sobreescribe. Android 10+ usa MediaStore (sin permisos) y versiones anteriores la ruta clásica con permiso de almacenamiento.
- **Compartir**: usa `FileProvider` de AndroidX, por lo que el XML puede enviarse por cualquier aplicación instalada.
