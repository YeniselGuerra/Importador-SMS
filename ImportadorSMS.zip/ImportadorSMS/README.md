# Importador SMS

Aplicación Android que lee **todos los SMS del teléfono** (recibidos y enviados), los guarda en una base de datos local dentro de la app, muestra el listado de los importados y los **exporta a un archivo XML** en la carpeta Descargas, listo para importarse en la base de datos del sistema de inventario.

Los mensajes no se pierden al cerrar la app: quedan guardados en la base local `sms_importados.db` y no se duplican aunque se importe varias veces.

## 1. Qué hace la aplicación

La pantalla principal tiene tres botones y una lista:

| Botón | Acción |
|-------|--------|
| **Importar SMS del teléfono** | Pide el permiso de SMS (la primera vez) y lee todos los mensajes de la bandeja de entrada (`RECIBIDO`) y de los enviados (`ENVIADO`). Guarda en la base local solo los que no estaban y muestra un resumen: cuántos nuevos entraron, cuántos ya estaban y cuántos dieron error. |
| **Exportar XML a Descargas** | Genera `sms_export_FECHA_HORA.xml` con todos los mensajes guardados y lo deja en la carpeta **Descargas** del teléfono. |
| **Compartir el último XML** | Abre el menú de compartir de Android (Drive, correo, WhatsApp, etc.) con el último XML exportado. |

Debajo de los botones se muestra en todo momento el estado de la base local (total, recibidos y enviados) y la ruta del último archivo exportado. La lista muestra cada mensaje con su remitente o destinatario, la fecha y las primeras líneas del texto.

## 2. Instalación y permisos

Instale el APK (ver sección 4) y ábralo. Al pulsar **Importar SMS** por primera vez, Android pedirá el permiso **SMS**: acéptelo, es necesario para leer los mensajes. Si lo rechaza, la app lo indica y se puede conceder después en **Ajustes → Aplicaciones → Importador SMS → Permisos → SMS**.

- En **Android 10 o superior** no se pide ningún permiso más: el XML se guarda en Descargas sin permisos adicionales.
- En **Android 9 o anterior** se pide además el permiso de **almacenamiento** al exportar, para poder escribir en la carpeta Descargas.

Nota: Google Play restringe las apps que piden permiso de SMS, pero esta aplicación se instala directamente con el APK (fuera de Play), donde el permiso funciona con normalidad. No es necesario que la app sea la aplicación de SMS predeterminada para leer los mensajes.

## 3. Formato del XML exportado

Cada archivo tiene un elemento raíz `mensajes_sms` con atributos de control y un elemento `mensaje` por cada SMS guardado:

```xml
<?xml version="1.0" encoding="UTF-8"?>
<mensajes_sms app="ImportadorSMS" version="1.0" total="2" exportado="2026-11-23T19:05:00">
  <mensaje>
    <id>1</id>
    <id_sistema>42</id_sistema>
    <tipo>RECIBIDO</tipo>
    <telefono>+5355123456</telefono>
    <fecha_unix>1732311900000</fecha_unix>
    <fecha>2026-11-22 19:05:00</fecha>
    <leido>SI</leido>
    <texto>INV|MARCA:Samsung|MODELO:A15|IMEI:356789...</texto>
  </mensaje>
  <mensaje>
    <id>2</id>
    <id_sistema>43</id_sistema>
    <tipo>ENVIADO</tipo>
    <telefono>+5355123457</telefono>
    <fecha_unix>1732312000000</fecha_unix>
    <fecha>2026-11-22 19:06:40</fecha>
    <leido>SI</leido>
    <texto>Trabajo enviado, saludos</texto>
  </mensaje>
</mensajes_sms>
```

Equivalencia de campos para crear o ajustar la tabla en la base de datos:

| Campo XML | Tipo sugerido en la BD | Significado |
|-----------|------------------------|-------------|
| `id` | ENTERO | Identificador en la base local de la app (orden de importación) |
| `id_sistema` | TEXTO | Identificador del mensaje en el sistema del teléfono |
| `tipo` | TEXTO | `RECIBIDO` (bandeja de entrada) o `ENVIADO` |
| `telefono` | TEXTO | Número del remitente (recibidos) o destinatario (enviados) |
| `fecha_unix` | ENTERO (BIGINT) | Fecha en milisegundos desde 1970 (ordenación exacta) |
| `fecha` | TEXTO / FECHA | Fecha legible `AAAA-MM-DD HH:MM:SS` (hora del teléfono) |
| `leido` | TEXTO / BOOLEANO | `SI` o `NO` según estaba leído en el teléfono |
| `texto` | TEXTO | Contenido completo del mensaje |

Atributos de la etiqueta raíz: `total` (cantidad de mensajes), `exportado` (fecha-hora de la exportación), `app` y `version`.

Detalles útiles para la importación:

- El texto está **escapado en XML** (`&amp;`, `&lt;`, `&gt;`, `&quot;`, `&apos;`); cualquier lector XML estándar lo decodifica solo. Los caracteres de control inválidos se sustituyen por espacio.
- El par (`tipo`, `id_sistema`) identifica un mensaje de forma única dentro del teléfono: si la base de datos guarda esos dos campos con un índice único, se puede reimportar el mismo XML sin crear duplicados.
- `fecha_unix` recomienda usarse para ordenar; `fecha` es para lectura humana.
- Si su base de datos necesita otros nombres de etiquetas u otro orden de campos, indíquelo y se ajusta el exportador.

## 4. Cómo compilar el APK

### Opción A — Android Studio

1. **File → Open** y seleccione la carpeta `ImportadorSMS`.
2. Espere la sincronización de Gradle (la primera vez descarga dependencias).
3. **Build → Build Bundle(s)/APK(s) → Build APK(s)**.
4. El APK queda en `app/build/outputs/apk/debug/app-debug.apk`.

### Opción B — Línea de comandos

Requisitos: JDK 11 o 17 y conectividad para descargar Gradle 7.6.4 y las librerías.

```bash
cd ImportadorSMS
./gradlew assembleDebug        # Linux/Mac
gradlew.bat assembleDebug      # Windows
```

### Opción C — Compilar online gratis con GitHub Actions (sin instalar nada)

Igual que con la app anterior: **son dos subidas**, porque GitHub no mira dentro de los ZIP.

1. **New repository** → nombre `importador-sms` → visibilidad **Public** → **Create repository**.
2. Pulse **“uploading an existing file”**, arrastre el archivo `ImportadorSMS.zip` → **Commit changes**.
3. **Add file → Create new file** → como nombre escriba `.github/workflows/build-apk.yml` → pegue el contenido del archivo `build-apk.yml` que está incluido en el ZIP dentro de `ImportadorSMS/.github/workflows/` (el mismo que se describe abajo) → **Commit changes**.
4. La pestaña **Actions** mostrará “Compilar APK” en ejecución (5–15 minutos).
5. Al terminar (✔ verde), entre en la ejecución y baje a **Artifacts**: descargue `ImportadorSMS-apk`, que contiene `ImportadorSMS.apk`.
6. Pase el APK al teléfono e instale aceptando “fuentes desconocidas”.

El workflow incluido (`.github/workflows/build-apk.yml`) instala Java 17, descomprime el ZIP del repositorio, compila con Gradle y publica el APK como artefacto; si la compilación falla, muestra las últimas líneas del error en la página de resumen del run.

### Compatibilidad de versiones

| Componente | Versión usada |
|------------|---------------|
| Gradle | 7.6.4 (el wrapper lo descarga solo) |
| Android Gradle Plugin | 7.4.2 |
| Kotlin | 1.8.22 |
| compileSdk / targetSdk | 33 |
| minSdk | 21 (Android 5.0 en adelante) |

## 5. Notas técnicas

- **Base local**: SQLite (`sms_importados.db`), tabla `sms` con columna única (`tipo`, `id_sistema`) que garantiza que reimportar no duplique mensajes. Se pueden importar miles de mensajes sin problema; la lectura ocurre en un hilo aparte para no bloquear la pantalla.
- **Fuente de datos**: el proveedor de SMS del sistema (`content://sms/inbox` y `content://sms/sent`). Algunos teléfonos muy personalizados renombran los mensajes de operador, pero el esquema de columnas (`_id`, `address`, `body`, `date`, `read`) es estándar en Android 5 o superior.
- **Archivos exportados**: `sms_export_AAAAMMDD_HHMMSS.xml`. Cada exportación crea un archivo nuevo con la fecha y hora en el nombre, así que nunca se sobreescribe una exportación anterior. Para Android 10+ se usa MediaStore (carpeta Descargas sin permisos) y para versiones anteriores la ruta clásica de Descargas con el permiso de almacenamiento.
- **Compartir**: usa `FileProvider` de AndroidX, por lo que el XML puede enviarse por cualquier aplicación instalada sin riesgos de permisos entre apps.
